# Servidor y plugins de SCP:SL

Este repositorio mantiene organizadas las carpetas del servidor y sus plugins:

- [EXILED](./EXILED/) — configuración del servidor, inventario de plugins instalados y documentación de mantenimiento.
- [LabAPI](./LabAPI/) — plugins instalados de LabAPI, dependencias, configuración del cargador y configuraciones de plugins.

El archivo raíz [.gitignore](./.gitignore) excluye artefactos de compilación, estado del editor, registros, bases de datos locales y directorios de ejecución del juego/servidor.

La instalación del juego y del servidor dedicado se mantiene fuera de este árbol de archivos. La clave de CedMod no se incluye en la copia versionada; los datos generados de jugadores permanecen en la carpeta local, pero se excluyen del control de versiones.
