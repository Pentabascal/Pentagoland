# Inventario y mapa de rutas

## 1. Código fuente de terceros pendiente

Los checkouts completos se agruparon por función bajo `Pendientes Por Configurar e Instalar/`. Cada carpeta de checkout conserva su contenido interno y su nombre de origen.

| Categoría | Checkouts |
|---|---|
| `01 - Interfaz y HUD` | `UsefulHints-3.1.3`, `ScpsInfoDisplay-9.0.0` |
| `02 - Comunicación` | `KillMessage-1.0.8-9`, `KillMessage-main`, `Talky-1.0.0-pre1` |
| `03 - Progresión y estadísticas` | `MvpSystem-main`, `StatsSystem-2.1.1`, `XP-2.1.2` |
| `04 - Gameplay y seguridad` | `EffectKeeper-2.0.1`, `Sunrise-1.4.9` |
| `05 - Utilidades y permisos` | `RemoteKeycard-3.4.2`, `SCPUtils-6.5.5` |

`KillMessage-1.0.8-9` y `KillMessage-main` no se combinaron. Son dos checkouts/variantes y se deben comparar antes de elegir cuál publicar o mantener.

### Excepciones que permanecen en la raíz de pendientes

- `ScpSwap-1.3.0`: no se movió porque el `.csproj` usa `..\..\..\Exiled_Resources\...`, una ruta relativa fuera del checkout que cambiaría al reubicarlo.
- `dependencies` y `dependencies1`: no se tocaron; su alcance/uso compartido no está suficientemente claro para reubicarlas con seguridad.
- `README INFO PLUGINS.txt`: se conserva en su ubicación original como referencia del lote descargado.

## 2. Artefactos DLL de pendientes

Los DLL que estaban sueltos en la raíz ahora tienen una carpeta individual por plugin en `Pendientes Por Configurar e Instalar/Binarios pendientes/`:

- `01 - Interfaz y HUD`: `IntercomDisplayInfo`, `ScpsInfoDisplay`, `UsefulHints` (incluye `UsefulHints.Addons`) y `Watermark`.
- `02 - Comunicación`: `Talky`.
- `03 - Progresión y estadísticas`: `MvpSystem`, `StatsSystem` y `XPSystem`.
- `04 - Gameplay y seguridad`: `AntiSuicidalZombies`, `EffectKeeper` y `FacilityManagement`.
- `05 - Utilidades y permisos`: `ScpSwap` y `SCPUtils`.
- `06 - Administración`: `AdminTools`, `LateSpawn`, `ModeratorTools` y `VPNGuard`.
- `07 - Dependencias compartidas`: `LabApiExtensions`.

El archivo `StatsSystem-2.1.1.zip` está junto a los artefactos de StatsSystem. Se preservaron nombres y contenido; estos artefactos no se instalaron ni se activaron.

## 3. Proyectos propios y artefactos compilados

`zCreacionPlugins/` contiene estos checkouts fuente, que se dejaron en sus rutas originales:

- `SnivysUltimatePackage-master/`: solución VVUP multi-proyecto.
- `SUBCLASES/SubclassFramework/`: proyecto independiente que también sirve de referencia a VVUP.
- `Grenade-Launcher-SCP-SL-plugin-sound-included--scp1/`: proyecto con referencia absoluta de compilación a AudioPlayerApi.

No mover esos checkouts: `VVUP.SubclassCompatibility` referencia `SUBCLASES` mediante una ruta relativa, `Directory.Build.props` contiene una ruta absoluta local a las referencias de SubclassFramework y los proyectos usan referencias externas bajo `SL_REFERENCES`.

Los 13 DLL sueltos de `zCreacionPlugins/` quedaron ordenados por plugin en `zCreacionPlugins/Artefactos compilados/`:

- `01 - Interfaz y HUD`: `EffectDisplay`, `ScpsInfoDisplay`, `UltimateHUD`, `UsefulHints` y `UsefulHints.Addons`.
- `02 - Administración`: `AdminTools` y `CedModV3`.
- `03 - Gameplay`: `FacilityManagement`.
- `04 - Comunicación`: `ScpProximityChat.Core` y `ScpProximityChat.SecretAPI`.
- `05 - Dependencias`: `LabApiExtensions`, `SecretAPI` y `Timers`.

Son binarios compilados/aislados, no fuentes ni confirmación de que deban instalarse.

## 4. Configuración y producción — no reubicar

- `Configs/Plugins/<plugin>/`: configuraciones EXILED por plugin/puerto; `Configs/Translations/`, `Configs/UncomplicatedCustomItems/`, `Configs/XPSystem/`, `Configs/AdminTools/` y `Configs/CreditTags/` se mantienen intactos.
- `Plugins/7777/`: ruta de plugins EXILED del puerto 7777 indicada por la documentación del servidor.
- `Plugins/staging/` y `Plugins/backups/`: staging/rollback; no son fuentes para activar directamente.
- `Plugins/dependencies/`: dependencias del servidor.
- LabAPI usa rutas bajo `%AppData%\SCP Secret Laboratory\LabAPI\plugins\7777\` y `%AppData%\SCP Secret Laboratory\LabAPI\dependencies\7777\`, según `Plugins/README_SERVIDOR.md`.
- `DisabledPlugins/`: plugins conservados intencionalmente deshabilitados.
- `Plugins/README_SERVIDOR.md` registra el estado conocido, incluyendo exclusiones para evitar duplicar HUD/hints y objetos personalizados. Confirma el estado en logs actuales antes de cualquier operación: este inventario no ejecutó ni probó el servidor.

## 5. GitHub

El repositorio Git de la raíz no tiene commits ni remotos configurados. Se añadió un `.gitignore` válido basado en el antiguo `.gitignore.txt`; ignora `.vs/`, `bin/`, `obj/`, logs y `*.bak`, pero no DLLs, configuraciones, dependencias o datos del servidor. Para publicar, selecciona el checkout fuente de cada plugin, revisa su licencia/README y comprueba con `git status` qué se incluirá. No subas a ciegas `Configs/`, `Plugins/`, `backups/`, DLLs compilados o dependencias del servidor.
