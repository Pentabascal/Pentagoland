# Guía para IAs y colaboradores

Este directorio es el punto de entrada para entender el workspace `EXILED`. La organización se hizo el 26/09/2026; el estado operativo del servidor se basa en la documentación revisada, actualizada entre el 24 y el 25/09/2026. No se reinstalaron ni activaron plugins.

## Antes de cambiar nada

1. Lee [`INVENTARIO_Y_RUTAS.md`](INVENTARIO_Y_RUTAS.md) y después los README del proyecto concreto.
2. Separa **código fuente**, **artefactos descargados/compilados**, **configuración** y **plugins activos**. Un DLL en `Binarios pendientes` o `Artefactos compilados` no es una orden para instalarlo.
3. No muevas ni renombres `Plugins/7777`, `Configs`, `DisabledPlugins`, `Plugins/staging`, `Plugins/backups` ni las carpetas de LabAPI. Son rutas de producción, configuración, rollback o staging descritas en `Plugins/README_SERVIDOR.md`.
4. No dividas `SnivysUltimatePackage-master` ni separes `SUBCLASES`: VVUP tiene referencias cruzadas con `SubclassFramework` y rutas de compilación externas. No muevas `ScpSwap-1.3.0`: su proyecto apunta a `Exiled_Resources` mediante una ruta relativa externa al checkout.
5. Conserva los dos checkouts de KillMessage como variantes distintas hasta compararlos; no sobreescribas ni borres ninguno.
6. No publiques todo este workspace como un único repositorio sin revisar antes DLLs, configuraciones del servidor, backups, logs, licencias, dependencias y datos potencialmente privados.

## Fuentes de estado

- Estado, rutas activas y reglas de compatibilidad del servidor: [`../Plugins/README_SERVIDOR.md`](../Plugins/README_SERVIDOR.md), [`../Plugins/ESTADO_PLUGINS.txt`](../Plugins/ESTADO_PLUGINS.txt) y [`../Plugins/AUDITORIA_COMPATIBILIDAD_2026-09-24.txt`](../Plugins/AUDITORIA_COMPATIBILIDAD_2026-09-24.txt).
- El `README.txt` de la raíz contiene instrucciones antiguas y amplias de instalación; no prevalece sobre el estado y las reglas actuales de `Plugins/`.
- Se añadió `../.gitignore` con las reglas de `../.gitignore.txt`; el archivo original se conservó. Git ahora ignora `.vs/`, `bin/`, `obj/`, logs y `*.bak`, pero esto **no** excluye por sí solo DLLs, configuraciones, dependencias ni datos del servidor.

## Validación de esta reorganización

Se movieron carpetas completas de checkouts pendientes y DLLs que estaban sueltos; no se editaron sus fuentes. Se verificaron 502 archivos estables de los checkouts y los 32 DLLs trasladados mediante SHA-256, sin diferencias; también se comprobó que las referencias internas de soluciones/proyectos siguieran resolviendo. 14 archivos bajo `obj` difirieron: son cachés/archivos generados de compilación y no código fuente; no se borraron. No se compilaron plugins ni se reinició el servidor.
