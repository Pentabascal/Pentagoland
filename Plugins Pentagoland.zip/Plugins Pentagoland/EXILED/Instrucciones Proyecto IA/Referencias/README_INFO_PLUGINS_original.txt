Talky v1.0.0-pre1 Pre-release
@tayjay tayjay released this Jun 21
· 27 commits to next/1.0 since this release
 v1.0.0-pre1
 0cb9e54
Stable Release below is the recommended version for 14.X. This pre-release is for if you want to help test the next version.
With SCP:SL approaching its 15.0 release, I feel this is a good time to rewrite Talky to be more maintainable and built to a single DLL that will work in both Exiled and LabApi.
This pre-release works in the current SCP:SL version 14.2.7.

This version could still see a major overhaul if my open suggestion is approved.

TL;DR
Talky is now a single DLL that works in both Exiled and LabApi plugin directories.
You will need to remove the old Talky.LabAPI.dll and Talky.Exiled.dll from your plugins folder and copy any config changes from your old Talky configs to the new Talky config.
This update includes performance improvements, bug fixes, and preparations for changes coming in 15.0.

If you experience bugs please report them as a GH Issue, or send a message/thread in one of the Talky Discord channels.

LabAPI Post
EXILED Channel
Breaking Changes
Change to single DLL build.
Will require removing old Talky.LabAPI.dll and Talky.Exiled.dll from plugins folder
Will require copying any config changes from old Talky configs to new Talky config.
Renamed plugin to Talky
Changes
Speaking logic applies to all roles to allow for all roles with human models to animate.
Speech processing now accepts proximity, radio, and intercom voice channels instead of requiring HumanVoiceModule/IVoiceRole.
Improve CedMod patching logic to target both Exiled and LabApi consistently
Opus sample buffer changed to 4800, sample array changed to 480 to match packet sizes, and volume decoding cleanup
Move compatibility checks to ServerEvents.PluginsEnabled to ensure all LabApi and Exiled assemblies are loaded before checking for them.
Add HarmonyPresent() checks and null guards before applying/removing patches to avoid errors when Harmony is not present. Remove snapshot system and related code.
Enable Talking setting changes now update SpeechTracker.ShouldAnimateFace rather than resetting the player emotion.
Change the project build target to explicit x64 to hide build warnings.
Fixes
SpeechTracker.defaultPreset is cached on init and updated when the player setting changes.
Look optimization: fake look sync now early-returns when both current and previous look offsets are zero.
Early return LookOverride if no offset is needed.
Clean up emotion override logic
Emotion override timing now uses Time.time seconds instead of Unix milliseconds
Glance/look cleanup: removed redundant checks
Tidy up complaints from the linter / / / / /


KillMessage
An EXILED plugin that shows a customizable message to players you kill.

IT SHOULD BE SAFE TO USE THE SAME DATABASE IN MULTIPLE SERVERS AT ONCE

Github All Releases

Available Commands
kmsg set - Sets your kill message
kmsg delete - Deletes your kill message
kmsg toggle - Toggles whether or not you can see kill messages
kmsg color - Sets your kill message color
Configs
Config	Type	Description	Default
is_enabled	bool	Whether the plugin is enabled	true
database_folder	string	The folder where the database will be stored in	PLUGINS_FOLDER/KillMessage
use_permissions	bool	Whether or not use permissions to be able to use commands. Permission: kmsg	false
send_console_message	bool	Whether or not send a message through the client console to a player who joins to tell them about the plugin	true
char_limit	int	Message's character limit	32
message_size	int	Size of the message that's shown to the killed player	30
message_duration	ushort	Duration of the message that's shown to the killed player	3
available_colors	string[]	List of available colors. MAKE SURE TO WRITE THEM IN LOWER CASE AND USE SCPSL WIKI COLORS	pink, red, brown, silver, light_green, crimson, cyan, aqua, deep_pink, tomato, yellow, magenta, blue_green, orange
Permissions
Permission	Description
kmsg	Permission to run all commands (except 'kmsg color')
kmsg.color	Permission to run 'kmsg color'
Give permission to all users
If you want to give all users a permission, there should be a group in your permissions.yml file called 'user' with default set to true, simply add the permission you want to give to everyone there.
Colors
For broadcast, you'll need to use colors from Unity Rich Text (Some of them will probably not work)
For hints i've tested, and only red, yellow, orange, black, blue, green, grey, lightblue, purple work.
You can also use Hex without needing to add the colors to the config / / / / / 



FacilityManagement
This plugin makes many things possible on your server.

Configs
Name	TypeValue	Description
IsEnabled	bool	Is the plugin enabled?
InfiniteAmmo	List<ItemType>	Items with InfiniteAmmo
EnergyMicroHid	float	Multiplier consumption of MicroHID (0 = No energy drain \ 2 = Double energy drain)
EnergyRadio	float	Multiplier consumption of EnergyRadio (Same as above)
GeneratorDuration	float	Time for the generator to be activated after being enabled (-1 disables the config)
LiftMoveDuration	Dictionary<ElevatorType, float>	Change the times of elevator Animation
StandardAmmoLimits	Dictionary<AmmoType, ushort>	Sets the standard ammo limits for the player
StandardCategoryLimits	Dictionary<ItemCategory, sbyte>	Sets standard category limits
CustomText	Dictionary<Intercom.State, string>	Change the intercomText with specified State
WarheadCleanup	bool	Remove all pickups and ragdoll in the facility (lower than y 500)
CustomTesla	TeslaBuild	(Null disables the change)
CustomScp914	Scp914Build	(Null disables the change)
CustomWindows	Dictionary<GlassType, GlassBuild>	Modify all the properties of Window as desired (null makes no change)
CustomDoors	Dictionary<DoorType, DoorBuild>	Modify all the properties of Door as desired (null makes no change)
RoleTypeHumeShield	Dictionary<RoleTypeId, AhpProccessBuild>	Create a custom AHP/HS for specified RoleType
CustomItem	Dictionary<ItemType, ItemBuild>	Create a custom AHP/HS for specified RoleType
CustomRole	Dictionary<RoleTypeId, RoleBuild>>	Create a custom AHP/HS for specified RoleType
TeslaBuild
PropertyName	TypeValue	Description
IgnoredRoles	List<RoleTypeId>	Tesla ignores players with this Role (Null disables the change)
TriggerRange	float?	Distance for tesla to be triggered (Null disables the change)
IdleRange	float?	Distance for tesla to start idling (Null disables the change)
ActivationTime	float?	Time for tesla to start (Null disables the change)
CooldownTime	float?	Time between each shock (Null disables the change)
Scp914Build
PropertyName	TypeValue	Description
KnobChangeCooldown	float?	Cooldown between each interaction for when people modify the knob (Null disables the change)
DoorCloseTime	float?	Delay after the interaction then the Door will Close (Null disables the change)
ItemUpgradeTime	float?	Delay after the interaction then the content of Scp914 will be upgraded (Null disables the change)
DoorOpenTime	float?	Delay after the interaction then the Door will Open (Null disables the change)
TotalSequenceTime	float?	Cooldown for Scp914 to be reusable again (Null disables the change)
GlassBuild
PropertyName	TypeValue	Description
Health	float?	Health of the window (Null disables the change)
DisableScpDamage	bool?	Disable the damage of Scp (Null disables the change)
DoorBuild
PropertyName	TypeValue	Description
Health	float?	Health of the door (Null disables the change)
RequiredPermission	KeycardPermissions	Change the RequiredPermission for interaction with the Door (Null disables the change)
RequireAllPermission	bool?	Require all the permissions of RequiredPermission (0 or None disables the change)
DamageTypeIgnored	DoorDamageType	Modify the DamageType ignored by the Door (0 disables the change)
AhpProccessBuild
PropertyName	TypeValue	Description
amount	float	Max AHP/HS
regen	float	Amount of Regen per second (decay if negative)
efficacy	float	Amount of damage taken by AHP/HS (0 = Useless/ 1 = Perfect)
sustain	float	Required time before regen reactivates when player takes damage
ItemBuild
This ItemBuild permits the creation of a highly configurable default item value.

You can find all properties that you can modify in this link. You can only modify properties that have basic types like float, int, byte, Enum, Vector3. Some properties might not work; they need to be synced with Exiled.

PropertyName	TypeValue	Description
Custom	List	Each string needs to contain PropertyName: Value
RoleBuild
This RoleBuild permits the creation of a highly configurable default Role value.

You can find all properties that you can modify in this link. You can only modify properties that have basic types like float, int, byte, Enum, Vector3.

PropertyName	TypeValue	Description
Custom	List	Each string needs to contain PropertyName: Value
CustomTextForIntercom
This plugin makes it possible to customize the IntercomText on your server; it’s updated every tick.

This plugin uses CommandInterpolation to allow you to create custom text that can change based on what is happening on the server.

We have added some CommandInterpolations for Intercom.

CommandInterpolation
CommandInterpolation	ReturnValue	Description
intercom_speech_remaining_time	int	Remaining speech time of the player to talk at intercom_bypass_speaking.
intercom_remaining_cooldown	int	Waiting time to talk again at intercom
intercom_is_in_use	bool	Intercom is being used
intercom_is_admin_speaking	bool	Is an admin who speaks at intercom
intercom_bypass_speaking	bool	Is a player speaking at intercom with bypass
intercom_mute_player_speak	bool	Is a player actually trying to talk and being muted
intercom_speaker_nickname	string	Nickname of the player at intercom
intercom_custom_text	string	The modified text by admin or plugin / / / / / 



What is Scripted Events Reloaded?
Scripted Events Reloaded (SER) is an SCP:SL plugin that adds a custom scripting language for server-side events.

Main goal
Making plugins with C# is NOT an easy thing, especially for beginners. If you want to get started with SCP:SL server-side scripting, SER is a great way to begin.

SER simplifies the most essential plugin features into a friendly package. All you need to get started is a text editor and a server!

Nice-to-Haves of SER
Simplification of the most essential features like commands, events, and player management.
No compilation required, while C# plugins require a full development environment, compilation, and DLL management.
Lots of built-in features like custom roles, audio, map editor, databases, Discord webhooks, HTTP, and more!
Extendable with integrations such as UCR, EXILED, Callvote, and ProjectMER, but only when you need it - no unnecessary dependencies!
Plugin docs are available directly on the server using the serhelp command.
Helpful community available to help you with any questions you may have.
SER Tutorials
Want to make something useful before studying the language? Follow the outcome-first tutorial. Need an exact rule or edge case? Jump to the technical reference. Both are versioned with the plugin:

SER 1.0 documentation

The previous GitBook documents older releases and is not the source of truth for the current 1.0 branch.

SER editing tools
SER ships one synchronized editing system in two forms:

SER Blocks, a standalone beginner editor generated as SER Visual Editor.html;
a VS Code extension with completions, hovers, shared diagnostics, and the same visual editor available through SER: Open Blocks Editor.
Quick start
Install SER.dll as a LabAPI plugin and start the server once.

Open the script directory shown by serhelp start or serstatus.

Create hello.ser containing:

Print "Hello from SER!"
Run serrun hello. SER discovers or reloads the requested file immediately before creating the runnable script.

Use serreload when you want to refresh the complete directory at once, and serstatus to see accepted, failed, disabled, excluded, linked, and conflicting paths.

.ser is the preferred extension. .txt is an identical compatibility format for server hosts whose file managers do not allow users to open unknown file types. A script name is global: two files with the same base name cannot coexist, even in different folders.

Run serexamples to generate validated examples. Their names begin with #, so they remain disabled until you copy one or remove the leading # and run serreload. A folder whose name begins with # is also disabled: SER skips the folder and its entire contents during script discovery. Linked folders (symbolic links and directory junctions) are also skipped so discovery cannot leave the SER directory or loop indefinitely.

Examples
The build validates every script in the Example Scripts directory. The short examples below use the same current syntax.

One .ser or .txt file may contain multiple independent handlers. Each !-- flag starts a new section that ends immediately before the next flag. Multi-section files can be addressed as filename:1, filename:2, and so on.

SER reloads the complete script directory when the plugin initializes and whenever the round restarts. Every file-backed script is also checked and reloaded immediately before execution, whether requested by serrun, an event, a callback, or another script. Use the permission-protected serreload command to refresh everything on demand, especially when adding or removing bindings that cannot trigger yet. Reloads are transactional: a changed file is compiled in full before its flags are replaced, and if validation fails, the last known-good version stays active.

!-- OnEvent RoundStarted
Print "Round started"

!-- OnEvent Death
Print "A player died"

!-- CustomCommand status
-- requireSender
Reply "Hello {@sender -> name}! The server is online"
ProjectMER integrations can use the dedicated optional event entry point:

!-- OnPMER SchematicSpawned
-- require *evSchematic

Print "Spawned {$evName}"
MER.PlayAnimation *evSchematic "Open"
UncomplicatedCustomRoles 9.6.0 or newer exposes role lifecycle events too:

!-- OnUCR Spawned
-- require @evPlayer *evRole

Hint @evPlayer 5s "You spawned as {*evRole -> name}."
Welcome message
!-- OnEvent Joined
-- require @evPlayer

Broadcast @evPlayer 10s "Welcome to the server {@evPlayer -> name}!"
Coin on kill
!-- OnEvent Death
-- require @evAttacker

# give the attacker a coin
GiveItem @evAttacker Coin
VIP broadcast command
# define the command with custom attributes
!-- CustomCommand vipbc
-- description "broadcasts a message to all players - VIP only"
-- neededRank vip svip mvip
-- arguments message
-- availableFor player
-- requireSender
-- cooldown 2m

# send the broadcast to all players
Broadcast @all 10s "{@sender -> name} used VIP broadcast<br>{$message}"
Heal random SCP
!-- CustomCommand healscp
-- description "heals a random SCP"
-- availableFor Player
-- requireSender
-- cooldown 10s

# dont allow SCPs to use this command
if {@sender -> team} is "SCPs"
    stop
end

# get a random SCP that is not a SCP-079
@randomScp = Take {Except @scpPlayers @scp079Players} 1

# get 5% of the SCP's max health
$healAmount = Round ({@randomScp -> maxHealth} * 0.05)

Heal @randomScp $healAmount
Broadcast @randomScp 4s "{@sender -> name} healed you with {$healAmount} HP!"
For a complete event script, see hotPotato.ser, which is validated during every build.

Are you an LLM?
Check the syntax definition for guidance about SER script-making.

Building release artifacts
Run tools/package-release.ps1 from PowerShell. It rebuilds and verifies both plugin hosts and the editor tooling, then creates ready-to-install SER.dll and SER-Exiled.dll files, the examples/documentation bundle, the standalone editor, the VS Code extension, a complete bundle, and SHA256SUMS.txt under artifacts/. Release maintainers can pass -UcrReferencePath <path> to compile against the exact official UCR DLL selected for that compatibility baseline. / / / / / 



ModeratorTools
A new iteration of the old AdminTools plugin. Contains various tools to assist staff.

This plugin is built using my command system, allowing for the usage of custom player selectors in nearly all commands.

Tip
Check the wiki for more information.

Installation
Install Axwabo.CommandSystem
Follow the guide in the README to install Axwabo.Helpers and Harmony
Download the ModeratorTools.dll file from the releases page
Place the file in the plugins folder:
Windows: %appdata%\SCP Secret Laboratory\LabAPI\plugins\<port>
Linux: .config/SCP Secret Laboratory/LabAPI/plugins/<port>
Restart the server
Permissions
Check out the permission table here

By default, the plugin uses string-based permissions provided by LabAPI. To switch to using base-game permissions, set vanilla_permissions to true in the plugin’s configuration.

You’ll have to configure LabAPI permissions for staff to be able to use commands. The permissions configuration is located at:

Windows: %appdata%\SCP Secret Laboratory\LabAPI\configs\permissions.yml
Linux: .config/SCP Secret Laboratory/LabAPI/configs/permissions.yml / / / / / 



IntercomDisplayInfo
LabAPIGitHub all releasesGitHub forksGitHub

Enhances the Intercom display, turning it into a fully customizable, live information panel. It shows vital round statistics at a glance, including the round timer, player counts for each team, and the current Intercom status.

Features
Live Round Timer: Displays the current match time directly on the Intercom screen.
Team Counters: Shows the number of living players for Class-D, Scientists, Foundation Forces, Chaos Insurgency, and SCPs.
Real-Time Intercom Status: Provides clear status updates (e.g., Ready, In Use, Cooldown).
Fully Configurable: Enable or disable each piece of information via a simple config file.
Translation Support: Customize all displayed text and labels to fit your server’s language or style.
Dependencies
LabAPI v1.1.1 or newer is required for this plugin.
0Harmony
Installation
Make sure you have LabAPI v1.1.1 or a compatible version installed on your server.
Download the latest release of IntercomDisplayInfo.dll from the Releases Page.
Place the downloaded .dll file into your server’s plugin directory (.config/SCP Secret Laboratory/LabApi/plugins/(server-port/global)).
Download dependencies zip, extract it and place the content into (.config/SCP Secret Laboratory/LabApi/dependencies/(server-port/global)).
Restart the server. The configuration and translation files will be generated on the first run.
Configuration
After the first launch, two files will be created in your LabApi configuration folder: config.yml and translations.yml. / / / / / 




MvpSystemDownloads
An SCP: Secret Laboratory LabApi plugin which shows some statistics about the round and selects an MVP at the end of the round.

Features
Fully customizable in the config.
You can add MVP music for specific players using SecretLabNAudio. If they are the MVP the music will be played.
You need:
Format .ogg or .mp3
Channels: 1 ( MONO )
Freq: 48Khz
Option for muting the music. So you will not hear it. (Server-Specific Setting)
Compatible with StatsSystem.
If the StatsSystemIntegration is true in the config and the plugin is present, it will count the MVPs.
Installation
Install SecretLabNAudio-v2.0.0-beta2.
For installation check this README.md.
Download MvpSystem.dll and dependencies.zip.
Move MvpSystem.dll to => /SCP Secret Laboratory/LabApi/plugins/global/
Move dependencies.zip to => /SCP Secret Laboratory/LabApi/dependencies/global/ / / / / 



AntiSuicidalZombies (3.0.3)
Plugin for the “SCP: Secret Laboratory” game, that prevents Zombies (SCP-049-2) from suiciding by walking into a Tesla, jumping into a void or being crushed by a bulk door or an elevator.

Features
Zombies can have effect(s) applied to them after walking into Tesla.
Zombies, who jumped into void in HCZ, are teleported to one of the doors with no keycard permission in the same room.
Installation
Place AntiSuicidalZombies dll in “…\AppData\Roaming\SCP Secret Laboratory\LabAPI-Beta\plugins\global or port_number”.

Config
Name	Type	Default value	Description
debug	bool	false	Should debug be enabled?
tesla_effect	Dictionary<string, EffectParameters>	Blurred:
  intensity:1
  duration:10 Burned:
  intensity:1
  duration:30	Effects applied to zombies after walking into a tesla.
crushed_effects	Dictionary<string, EffectParameters>	Concussed:
  intensity:5
  duration:10 Deafened:
  intensity:1
  duration:20 Slowness:
  intensity:30
  duration:30	Effects applied to zombies after being crushed by a door or an elevator. / / / / / / LabApiExtensions
This is just a dependency and not a Plugin!

Features
Fake Mirror SyncObject
Fake Mirror SyncVar
Scale (from Exiled)
Dummy Extension
CustomDataStore with Type.
Effect Helpers
Damage Helpers
Install
Download from Github actions
Put into LabApi/dependencies/global/ folder.
Now you sucessfully installed this dependency! / / / / / 




StatsSystem
DownloadsVersionFrameworkLicense

SCP: Secret Laboratory LabAPI plugin for comprehensive, modular player statistics tracking.

Support


Features
Modular stat tracking — kills, deaths, playtime, SCP kills, MicroHID kills, Class D kills and more, all toggleable individually
Daily / historical stats — configurable time windows (e.g. last 7, 30, 90 days) for every tracked stat
Two storage backends — human-readable JSON or compact Binary format, swappable
Leaderboards — in-game leaderboard for any stat, including historical period views
Public API — full C# API for other plugins to read and write custom statistics
Admin tools — save, reload, reset and inspect stats via Remote Admin
Auto-save — configurable auto-save interval with file writes (no data corruption)
Installation
Download the latest StatsSystem.dll from GitHub Releases.
Place the DLL in your server’s folder.
Linux: ~/.config/SCP Secret Laboratory/LabAPI/plugins/global/
Windows: %appdata%/SCP Secret Laboratory/LabAPI/plugins/global/
Start the server — a default config.yml is generated automatically.
Adjust the config to your needs and reload.
Configuration
Configuration is located at:

Linux: ~/.config/SCP Secret Laboratory/LabAPI/configs/port/
Windows: %appdata%/SCP Secret Laboratory/LabAPI/configs/port/
Key	Default	Description
PlaytimeTracking	true	Track total playtime per player
KillsTracking	true	Track total kills
DeathsTracking	true	Track total deaths
KillsAsClassDTracking	true	Track kills made while playing as Class D
ClassDKillsTracking	true	Track kills where the victim is Class D
ScpKillsTracking	true	Track kills where the victim is an SCP
MicroHidKillsTracking	true	Track kills made with MicroHID
LastDays	[7, 30, 90]	Day ranges for historical stat display
StatsDataFolder	StatsSystem	Folder name for stat storage files
AutoSaveIntervalSeconds	60	How often stats are saved (minimum: 10)
StorageProvider	Json	Storage format: Json or Binary
Debug	false	Enable verbose debug logging
Commands
Player Commands (Client / Remote Admin)
Command	Aliases	Description
.getstat	.gs	View your own stats
.getstat <player>	.gs <player>	View another player’s stats by name or user ID
.getleaderboard <stat>	.gl <stat>	Top 10 players for a given stat
.gl <stat> <top>		Top N players for a stat
.gl <stat> last <days>		Top players for the last N days
.gl <stat> last <days> <top>		Top N players for the last N days
Leaderboard examples:

.gl Kills 20
.gl TotalPlayTime last 7
.gl ScpKills last 30 15
Admin Commands (Remote Admin / Game Console)
Requires the stat.manage permission.

Command	Aliases	Description
ss save	ss s	Immediately save all stats to disk
ss reload	ss r	Reload stats from disk
ss resetplayer <userId>	ss rp, ss reset	Delete all stats for a player
ss info	ss i	Show system status (player count, keys, auto-save interval)
Stat Modification (Remote Admin)
Requires the stat.manage permission.

Command	Description
addstat <player> <statKey> <amount>	Add to a stat value
removestat <player> <statKey> <amount>	Subtract from a stat value
setstat <player> <statKey> <value>	Set a stat to an exact value
deletestat <userId> <statKey>	Remove a stat key entirely
Storage
Stats are saved to:

Linux: ~/.config/SCP Secret Laboratory/LabAPI/configs/StatsSystem
Windows: %appdata%/SCP Secret Laboratory/LabAPI/configs/StatsSystem
(or player_stats.bin when using Binary storage)

JSON vs Binary
JSON	Binary
Human-readable	Yes	No
File size	Larger	~70% smaller
Speed	Slower	Faster
Editability	Easy	Requires tool
You can switch between formats at runtime — the plugin will automatically save in the old format and reload in the new one.

Default Stat Keys
Key	Type	Description
Kills	Counter	Total kills
Deaths	Counter	Total deaths
KillsAsClassD	Counter	Kills made while Class D
ClassDKills	Counter	Kills where victim was Class D
ScpKills	Counter	Kills where victim was an SCP
MicroHidKills	Counter	Kills with MicroHID
TotalPlayTime	Duration	Total time spent on server // / / / / 



VPNGuard
VersionLabAPI VersionSCP:SL VersionTotal Downloads

A SCP: Secret Laboratory LabApi plugin that prevent players to use VPN or Proxy.

Features
Blocks players using a VPN or Proxy from playing on the server.
Detection powered by proxycheck.io — accurate VPN/Proxy/Tor detection over HTTPS.
Saves the checked and banned IPs so the plugin does not waste your daily API quota.
If a player is blocked, it sends a detailed message to Discord (webhook).
Configuration
ProxyCheckApiKey — optional free key for proxycheck.io (leave empty for the keyless tier of 100/day, or get a free key for 1000/day).
BlockHostingProviders — also kick datacenter/hosting IPs (catches more VPNs, but may cause false positives).
AllowedIsps — ISP/provider name substrings that are never kicked. Pre-filled with cloud gaming services (GeForce NOW, Xbox Cloud Gaming, Shadow, Boosteroid) so legitimate cloud players are not blocked.
AllowedAsns — ASN numbers that are never kicked (e.g. AS20347).
Webhook — optional Discord webhook URL for kick notifications.
Cloud gaming (GeForce NOW etc.): these connect from datacenter IPs. With the default config they pass through, and the AllowedIsps allowlist guarantees they are never kicked — even if you enable BlockHostingProviders. / / / / / 




WatermarkGitHub Downloads (all assets, all releases)
Simple EXILED plugin that displays a permanent hint on screen using the RueI hint framework. It can be useful as a watermark for server owners.

Depencencies
EXILED 9.14.2: https://github.com/ExMod-Team/EXILED
RueI hint framework 3.1.2: https://github.com/pawslee/RueI
How to install
Download the latest release .dll file.
Put the file in your EXILED plugins folder.
Restart your server to activate the plugin. / / / / / 

TIENES QUE INSTALAR TODAS ESTAS PLUGINS Y CONFIGURARLAS A LA PERFECCION Y HACER QUE SEAN COMPATIBLES CON CUALQUIER OTRO PLUGIN INSTALADO Y SIN NINGUN SOLO PROBLEMA, TODO PERFECTO.